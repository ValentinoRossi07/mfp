﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyApi.Models
{
    public class MedicineDemand
    {
        public string Medicine { get; set; }
        public int Demand { get; set; }
    }
}
